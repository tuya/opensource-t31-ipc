# ./gen_nvram_zone --size=0x20000 --config=default.prop --output=nvram.img
