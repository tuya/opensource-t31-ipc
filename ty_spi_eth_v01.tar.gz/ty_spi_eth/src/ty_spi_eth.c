#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/ethtool.h>
#include <linux/skbuff.h>
#include <linux/delay.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/spi/spi.h>
#include <linux/miscdevice.h>
#include <linux/gpio.h>
#include <linux/kthread.h>
#include <linux/kfifo.h>

#define DRV_NAME    "ty_spi_eth"
#define TX_TIMEOUT  (HZ * 10)
#define TYPE_ETH_HEAD    0xAA
#define TYPE_CMD_HEAD    0xBB

/* SPI Head frame format 
 * ----------------------------------------------------------------------------------
 * | Head Type(1-byte) | reserved(3-byte) | Length(4-byte) | CRC32(4-byte)
 * ----------------------------------------------------------------------------------
 */
#define MAX_PKT_SIZE    1588
#define DATA_IRQ GPIO_PB(27)
#define GPIO_TO_MCU GPIO_PA(10)
#define ETH_SPI_FIFO_SIZE 262144
#define WAIT_ACK_TIMEOUT	(HZ/50)
#define SPI_ETH_PKT_SIZE 1600
#define IDLE 0
#define WAIT_MCU_INTR 1
#define READY_SEND_DATA 2
#define ACK_FROM_MCU 3
#define TX_STATUS 5

DECLARE_WAIT_QUEUE_HEAD(ack_done_wq);
atomic_t flag = ATOMIC_INIT(0);

struct ty_spi_header {
    u8 type;
    u8 reserved[3];
    u32 len;
    u32 crc32;
};

struct ty_spi_cmd {
    struct list_head list;
    u32 len;
    u8 data[];
};

struct ty_net_priv {
    struct net_device *ndev;
    struct spi_device *spi;
    struct miscdevice mdev;
    struct mutex lock;
    struct work_struct irq_work;
    struct work_struct tx_work;
    struct sk_buff *tx_skb;
    struct list_head cmd_list;
    struct kfifo ty_xmit_fifo;
    spinlock_t	ty_write_lock;
};

static int ty_recv_pkt(struct spi_device *spi, u8 *buf)
{

	struct spi_transfer	r = {
	    .tx_buf		= NULL,
        .rx_buf     = buf,
		.len		= SPI_ETH_PKT_SIZE,
	};
	struct spi_message	m;
    /* TODO: calculate and update crc32 */

	spi_message_init(&m);
    spi_message_add_tail(&r, &m);
	return spi_sync(spi, &m);
}

static int ty_send_pkt(struct spi_device *spi, const void *buf)
{
	struct spi_transfer	t = {
	    .tx_buf		= buf,
        .rx_buf     = NULL,
		.len		= SPI_ETH_PKT_SIZE,
	};
	struct spi_message	m;
    /* TODO: calculate and update crc32 */

	spi_message_init(&m);
    spi_message_add_tail(&t, &m);
	return spi_sync(spi, &m);
}

int convert(int la, int lb, int lc, int ld)
{
    la = 0xFFFFFF | (la << 24);
    lb = 0xFF00FFFF | (lb << 16);
    lc = 0xFFFF00FF | (lc << 8);
    ld = 0xFFFFFF00 | ld;
    return la & lb & lc & ld;
}

static void ty_irq_work_handler(struct work_struct *work)
{
    struct ty_net_priv *priv = container_of(work, struct ty_net_priv, irq_work);
    struct net_device *ndev = priv->ndev;
    struct ty_spi_header r_header;
    struct sk_buff *skb = NULL;
    int err;
    u8 spi_eth_rx_buf[1600] = {0};
    int i = 0;

    mutex_lock(&priv->lock);
    /*status: it is recv data from cs */
    err = ty_recv_pkt(priv->spi,spi_eth_rx_buf);
    if (!err) {
        r_header.type = spi_eth_rx_buf[0];
        r_header.len = convert(spi_eth_rx_buf[7],spi_eth_rx_buf[6],spi_eth_rx_buf[5],spi_eth_rx_buf[4]);
        r_header.len = ntohl(r_header.len);

        r_header.crc32 = convert(spi_eth_rx_buf[11],spi_eth_rx_buf[10],spi_eth_rx_buf[9],spi_eth_rx_buf[8]);
	r_header.crc32 = ntohl(r_header.crc32);

        if (r_header.len > MAX_PKT_SIZE) {
            ndev->stats.rx_errors++;
        }
        
        if (r_header.type == TYPE_ETH_HEAD) {
            skb = netdev_alloc_skb(ndev, r_header.len + NET_IP_ALIGN);
            if (!skb) {
                ndev->stats.rx_dropped++;
            } else {
                skb_reserve(skb, NET_IP_ALIGN);
               
                if (r_header.len != 0) {
                    memcpy(skb_put(skb, r_header.len), spi_eth_rx_buf + 12, r_header.len);
                    skb->protocol = eth_type_trans(skb, ndev);
        	        ndev->stats.rx_packets++;
        	        ndev->stats.rx_bytes += r_header.len;
        	        netif_rx_ni(skb);        
                } else {
                    ndev->stats.rx_errors++;
                    dev_kfree_skb(skb);
                }
            }
        } else if (r_header.type == TYPE_CMD_HEAD) {
	    	int i;
            struct ty_spi_cmd *cmd;
	    	int crc32=0;
            cmd = kzalloc(sizeof(*cmd) +  r_header.len, GFP_ATOMIC);
            if (!cmd)
                goto exit;
            
            memcpy(cmd->data, spi_eth_rx_buf + 12, r_header.len);
            cmd->len =  r_header.len;
            list_add_tail(&cmd->list, &priv->cmd_list);

	    	for(i=0;i<r_header.len;i++) {
	   	 		crc32 += cmd->data[i];
	    	}
            
	    	if(crc32 !=  r_header.crc32) {
	          printk(KERN_DEBUG "read crc32:%d(%x),cal crc32:%d(%x)\n",r_header.crc32,r_header.crc32,crc32,crc32);
	    	}
              
        } else {
            ndev->stats.rx_errors++;
            printk("###### r_header error type=%02X\n", r_header.type);
        }   
    }
exit:  
    mutex_unlock(&priv->lock);     
    
}

static irqreturn_t ty_spi_eth_irq(int irq, void *dev_id)
{
    struct ty_net_priv *priv = dev_id;
    
    if((atomic_read(&flag) == WAIT_MCU_INTR) || (atomic_read(&flag) == READY_SEND_DATA)){
        atomic_set(&flag, ACK_FROM_MCU);
	    wake_up(&ack_done_wq);    
    }
    
    if(atomic_read(&flag) == IDLE){
        schedule_work(&priv->irq_work);
    }

	return IRQ_HANDLED;
}

/*
 * Misc device operations
 */
static int ty_misc_open(struct inode *inode, struct file *filp)
{
    struct ty_net_priv *priv = container_of(filp->private_data,
             struct ty_net_priv, mdev);
	int ret = 0;

	ret = nonseekable_open(inode, filp);
	if (ret)
		return ret;

    return 0;
}

static int ty_misc_release(struct inode *inode, struct file *filp)
{
    return 0;
}

static ssize_t ty_misc_read(struct file *filp, char __user *buf, size_t count, loff_t *ppos)
{
    struct ty_net_priv *priv = container_of(filp->private_data,
             struct ty_net_priv, mdev);
    struct ty_spi_cmd *cmd = NULL;
    int ret = 0;

    if (count == 0)
        return 0;

    if(list_empty(&priv->cmd_list)) {
            ret = -1;
            goto out;
    }

    cmd = list_first_entry(&priv->cmd_list, struct ty_spi_cmd, list);
    list_del(&cmd->list);

    if (count < cmd->len) {
        ret = -1; 
        goto free;
    }
    
    if (copy_to_user(buf, cmd->data, cmd->len)) {
        ret = -1;
        goto free;
    }
    
    ret = cmd->len;

free:
    kfree(cmd);
out:
    return ret;
}

static ssize_t ty_misc_write(struct file *filp, const char __user *buf, size_t count, loff_t *ppos)
{
    struct ty_net_priv *priv = container_of(filp->private_data,
             struct ty_net_priv, mdev);
    unsigned char *cmd_data;
    int ret;
    struct ty_spi_header t_headr;
    int i;
    int crc32 = 0;
    int kfifo_avail = 0;

    if ((count == 0) || (count > MAX_PKT_SIZE)){
        printk(KERN_ERR "%s: invaild len = %d\n", __func__, count);
        return 0;
    }

    if(atomic_read(&flag) == IDLE){
        atomic_set(&flag, TX_STATUS);
    }

    /*create new pkt*/
    t_headr.type = TYPE_CMD_HEAD;
    t_headr.len= htonl(count);

    cmd_data = kzalloc(1600, GFP_ATOMIC);
    if (!cmd_data) {
        ret = -ENOMEM;
        goto out;
    }

    //memcpy(cmd_data, &t_headr, 12);

    if (copy_from_user(cmd_data + 12, buf, count)) {
        ret = -EFAULT;
        goto free;
    }

    for(i = 0;i <count;i++) {
        crc32 += cmd_data[12+i];
    }

    t_headr.crc32 = htonl(crc32);
    memcpy(cmd_data, &t_headr, 12);
    
    /*put data into  kfifo*/
    kfifo_avail = kfifo_avail(&priv->ty_xmit_fifo);
    if(kfifo_avail > 1600){
        kfifo_in_locked(&priv->ty_xmit_fifo,cmd_data,1600,&priv->ty_write_lock);
    }
    
    if(kfifo_len(&priv->ty_xmit_fifo) > 0){
        schedule_work(&priv->tx_work);
    }

    ret = count;
free:
    kfree(cmd_data);
out:
    return ret;
}

static const struct file_operations ty_misc_fops = {
    .owner = THIS_MODULE,
    .open = ty_misc_open,
    .release = ty_misc_release,
    .read = ty_misc_read,
    .write = ty_misc_write,
};

/*
 * Network device operations
 */
static int ty_net_open(struct net_device *ndev)
{
    struct ty_net_priv *priv = netdev_priv(ndev);

    netif_start_queue(ndev);

    return 0;
}

static int ty_net_close(struct net_device *ndev)
{
    struct ty_net_priv *priv = netdev_priv(ndev);

    netif_stop_queue(ndev);

    return 0;
}

static void ty_net_tx_work_handler(struct work_struct *work)
{
    struct ty_net_priv *priv = container_of(work, struct ty_net_priv, tx_work);
    struct net_device *ndev = priv->ndev;
    struct sk_buff *skb = priv->tx_skb;
    int ret = 0;
    u8 spi_eth_tx_buf[2048] = {0};

    mutex_lock(&priv->lock);
    while(kfifo_len(&priv->ty_xmit_fifo) > 0 ){  
       kfifo_out_locked(&priv->ty_xmit_fifo,spi_eth_tx_buf,1600,&priv->ty_write_lock);
retry:
        atomic_set(&flag, WAIT_MCU_INTR);
        /*data is ready send int to cs*/
        gpio_set_value(GPIO_TO_MCU,1);
        gpio_set_value(GPIO_TO_MCU,0);

        /*wait mcu intr ack*/
        ret = wait_event_interruptible_timeout(ack_done_wq, (ACK_FROM_MCU == atomic_read(&flag)), WAIT_ACK_TIMEOUT);
        if (!ret){
            //printk(KERN_ERR "%s: timeout when wait mcu intr\n", __func__);
            goto retry;
        }

        atomic_set(&flag, READY_SEND_DATA);
        ret = ty_send_pkt(priv->spi, spi_eth_tx_buf);
    
        if(ret == 0){
            /*wait mcu ack*/
            ret = wait_event_interruptible_timeout(ack_done_wq, (ACK_FROM_MCU == atomic_read(&flag)), WAIT_ACK_TIMEOUT);
            if (!ret){
                //printk(KERN_ERR "%s: timeout when wait mcu ack\n", __func__);
                goto retry;
            }      
        }

        atomic_set(&flag, IDLE);   
    }
    mutex_unlock(&priv->lock);
}

static netdev_tx_t ty_net_start_xmit(struct sk_buff *skb,
					struct net_device *ndev)
{
    struct ty_net_priv *priv = netdev_priv(ndev);
    unsigned char *spi_eth_pkt;
    struct ty_spi_header t_headr;
    int kfifo_avail = 0;

    if ((skb->len) > MAX_PKT_SIZE){
        printk(KERN_ERR "%s: invaild len = %d\n", __func__, skb->len);
        return NETDEV_TX_BUSY;
    }
    if(atomic_read(&flag) == IDLE){
        atomic_set(&flag, TX_STATUS);
    }
    /*create new pkt*/
    t_headr.type = TYPE_ETH_HEAD;
    t_headr.len= htonl(skb->len);

    spi_eth_pkt = kzalloc(SPI_ETH_PKT_SIZE, GFP_ATOMIC);
    if (!spi_eth_pkt)
        return -ENOMEM;

    memcpy(spi_eth_pkt, &t_headr, 12);
    memcpy(spi_eth_pkt + 12, (unsigned char*)skb->data, skb->len);
    /*put data into  kfifo*/
    kfifo_avail = kfifo_avail(&priv->ty_xmit_fifo);
    if(kfifo_avail > 1600){
        kfifo_in_locked(&priv->ty_xmit_fifo,spi_eth_pkt,1600,&priv->ty_write_lock);
    }
    
    ndev->stats.tx_packets++;
    ndev->stats.tx_bytes += skb->len;
    
    kfree(spi_eth_pkt);
    dev_kfree_skb(skb);
 
    if(kfifo_len(&priv->ty_xmit_fifo) > 0){
        schedule_work(&priv->tx_work);
    }
	
    return NETDEV_TX_OK;
}

static int ty_net_set_mac(struct net_device *ndev, void *addr)
{
	struct sockaddr *address = addr;

	if (netif_running(ndev))
		return -EBUSY;
	if (!is_valid_ether_addr(address->sa_data))
		return -EADDRNOTAVAIL;

	memcpy(ndev->dev_addr, address->sa_data, ndev->addr_len);
	return 0;
}

static void ty_net_tx_timeout(struct net_device *ndev)
{
	struct ty_net_priv *priv = netdev_priv(ndev);

	dev_err(&ndev->dev, DRV_NAME " tx timeout\n");

	ndev->stats.tx_errors++;

	if (netif_running(ndev)) {
        ty_net_close(ndev);
        ty_net_open(ndev);
    }
}

static const struct net_device_ops ty_netdev_ops = {
    .ndo_open = ty_net_open,
    .ndo_stop = ty_net_close,
    .ndo_start_xmit = ty_net_start_xmit,
    .ndo_set_mac_address = ty_net_set_mac,
    .ndo_tx_timeout = ty_net_tx_timeout,
    .ndo_validate_addr	= eth_validate_addr,
};

static const struct ethtool_ops ty_ethtool_ops = {
	.get_link = ethtool_op_get_link,
};

static int ty_spi_eth_probe(struct spi_device *spi)
{
    struct ty_net_priv *priv;
    struct net_device *ndev;
    int ret = 0;

    printk("ty_spi_eth version 2021.07.12 21:25\n");

    ndev = alloc_etherdev(sizeof(struct ty_net_priv));
    if (!ndev) {
        ret = -ENOMEM;
        goto err_alloc;
    }

    priv = netdev_priv(ndev);
    priv->ndev = ndev;
    priv->spi = spi;

    priv->mdev.name = DRV_NAME;
    priv->mdev.minor = MISC_DYNAMIC_MINOR;
    priv->mdev.fops = &ty_misc_fops;

    mutex_init(&priv->lock);
    spin_lock_init(&priv->ty_write_lock);
   
    INIT_LIST_HEAD(&priv->cmd_list);
    INIT_WORK(&priv->irq_work, ty_irq_work_handler);
    INIT_WORK(&priv->tx_work, ty_net_tx_work_handler);

    eth_hw_addr_random(ndev);
    spi_set_drvdata(spi, priv);
    SET_NETDEV_DEV(ndev, &spi->dev);

    if (kfifo_alloc(&priv->ty_xmit_fifo, ETH_SPI_FIFO_SIZE, GFP_KERNEL)) {
		ret = -ENOMEM;
	}

    ret = gpio_request_one(GPIO_TO_MCU, GPIOF_DIR_OUT, "gpio_to_mcu");
    if (ret < 0) {
        dev_err(&spi->dev, DRV_NAME ": request  gpio_to_mcu failed:%d\n", ret);
        goto err_alloc;
    }
    gpio_direction_output(GPIO_TO_MCU,0);

    ret = gpio_request_one(DATA_IRQ, GPIOF_DIR_IN, "data_irq");
    if (ret < 0) {
        dev_err(&spi->dev, DRV_NAME ": request data irq gpio failed:%d\n", ret);
        goto err_irq;
    }
    gpio_direction_input(DATA_IRQ);
    ret = request_irq(gpio_to_irq(DATA_IRQ), ty_spi_eth_irq, IRQF_TRIGGER_FALLING | IRQF_DISABLED, DRV_NAME, priv);
    if (ret < 0) {
		dev_err(&spi->dev, DRV_NAME ": request irq %d failed (%d)\n",
            spi->irq, ret);
		goto err_irq;
	}

    disable_irq(priv->spi->irq);

	ndev->if_port = IF_PORT_10BASET;
	ndev->irq = spi->irq;
	ndev->netdev_ops = &ty_netdev_ops;
	ndev->watchdog_timeo = TX_TIMEOUT;
	SET_ETHTOOL_OPS(ndev, &ty_ethtool_ops);

	ret = register_netdev(ndev);
	if (ret) {
		dev_err(&spi->dev, "register netdev " DRV_NAME " failed (%d)\n", ret);
		goto err_register;
	}

    ret = misc_register(&priv->mdev);
    if (ret) {
        dev_err(&spi->dev, "register misc device " DRV_NAME " failed (%d)\n", ret);
        goto err_misc;
    }

    enable_irq(priv->spi->irq);
	dev_info(&ndev->dev, DRV_NAME " driver registered\n");

	return 0;

err_misc:
    unregister_netdevice(ndev);
err_register:
	free_irq(spi->irq, priv);
err_irq:
	free_netdev(ndev);
err_alloc:
    return ret;
}

static int ty_spi_eth_remove(struct spi_device *spi)
{
	struct ty_net_priv *priv = spi_get_drvdata(spi);

    misc_deregister(&priv->mdev);
	unregister_netdev(priv->ndev);
	free_irq(spi->irq, priv);
	free_netdev(priv->ndev);

    kfifo_free(&priv->ty_xmit_fifo);

	return 0;
}

static struct spi_driver ty_spi_eth_driver = {
    .driver = {
        .name = DRV_NAME,
        .owner = THIS_MODULE,
    },
    .probe = ty_spi_eth_probe,
    .remove = ty_spi_eth_remove,
};

module_spi_driver(ty_spi_eth_driver);

MODULE_DESCRIPTION("tuya spi ethernet driver");
MODULE_LICENSE("GPL");