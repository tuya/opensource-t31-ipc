/*
 * Copyright (c) 2015 Olliver Schinagl <oliver@schinagl.nl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * This driver adds a high-resolution timer based PWM driver. Since this is a
 * bit-banged driver, accuracy will always depend on a lot of factors, such as
 * GPIO toggle speed and system load.
 */

#include <linux/mm.h>
#include <linux/fs.h>
#include <linux/clk.h>
#include <linux/pwm.h>
#include <linux/file.h>
#include <linux/list.h>
#include <linux/gpio.h>
#include <linux/time.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/module.h>
#include <linux/debugfs.h>
#include <linux/kthread.h>
#include <linux/mfd/core.h>
#include <linux/mempolicy.h>
#include <linux/interrupt.h>
#include <linux/mfd/jz_tcu.h>
#include <linux/miscdevice.h>
#include <linux/platform_device.h>

#include <soc/irq.h>
#include <soc/base.h>
#include <soc/extal.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/cacheflush.h>
#include <soc/gpio.h>
#include <mach/platform.h>

#define WL4455_START        0x4
#define WL4455_STOP         0x5

#define WL4455_DEVICE_NAME "wl4455"

struct breath_led_device {
	struct platform_device *pdev;
	struct device	 *dev;
	struct miscdevice misc_dev;
};

int gpio_num_433 =45;


 //1527 sync code
void coding_syn_1527(void)
{
  	gpio_set_value(gpio_num_433,1);
  	udelay(500);
  	gpio_set_value(gpio_num_433,0);
  	mdelay(15);
  	udelay(500);
	gpio_set_value(gpio_num_433,1);
 }
 //1527 code 0
void coding_L_1527(void)
{
	gpio_set_value(gpio_num_433,1);
	udelay(500);
	gpio_set_value(gpio_num_433,0);
	udelay(1500);
	gpio_set_value(gpio_num_433,1);
 } 
  //1527 code 1
void coding_H_1527(void)
{ 
  	gpio_set_value(gpio_num_433,1); 
  	udelay(1500);  
  	gpio_set_value(gpio_num_433,0);
  	udelay(500);
	gpio_set_value(gpio_num_433,1);
}

/*1527 encode
* input：   uint32_t addr   20位地址码
*          uint8_t data    4数据码
*/
void coding_1527(unsigned int addr_1527, unsigned long data)
{
  int i,k,j;

  //sync code
  coding_syn_1527();  
  //address code
  for(i=0;i<20;i++)
  {
    j = (0x80000 & addr_1527);
    addr_1527 = (addr_1527 << 1);
  if(j != 0)
    coding_H_1527();   
  else
    coding_L_1527();
  }

  //data
  for(i=0;i<4;i++)
  {  
   k = (0x08 & data);
   data = (data << 1);
	if(k != 0){
		coding_H_1527();
		if(i==3){
			gpio_set_value(gpio_num_433,0);
			udelay(10);
		}
	}
	else
		coding_L_1527();
	
	}
}

static long wl4455_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
  	unsigned long data = 1;
  	unsigned int addr_1527 = 0;
 	
	data = arg;
	addr_1527>>=12;
	
	switch (cmd) {
	
		case WL4455_START:
			{
			  	printk(KERN_ERR"wl4455_start\n");
			  	coding_1527(addr_1527,data);
				coding_1527(addr_1527,data);
				coding_1527(addr_1527,data);
				coding_1527(addr_1527,data);
			}
			break;

		case WL4455_STOP:
			{
			  	printk(KERN_ERR"wl4455_stop\n");
			  	gpio_set_value(gpio_num_433,0);
			}
			break;
			
		default:
			return -EINVAL;
	}

	return 0;
}
static struct file_operations wl4455_fops = {
	.unlocked_ioctl = wl4455_ioctl,
};

struct miscdevice wl4455_misc = {
    .minor  = MISC_DYNAMIC_MINOR,
    .name   = WL4455_DEVICE_NAME,
    .fops   = &wl4455_fops,
};

static int __init wl4455_init(void)
{
  int ret = 0;
  

  printk(KERN_ERR"wl4455_init\n");
	
		
	if(gpio_request(gpio_num_433, "433_gpio")) {
	      printk(KERN_DEBUG"request 433_gpio_num %d error!\n",gpio_num_433);
	      return -1;
      	}


	gpio_direction_output(gpio_num_433, 1);
	gpio_set_value(gpio_num_433,0);
	//udelay(1000);

	
	ret = misc_register(&wl4455_misc);
	if (ret < 0) {
		ret = -ENOENT;
		printk(KERN_ERR"misc_register failed\n");

	}

	printk(KERN_ERR"add wl4455 misc_register succeed\n");

	return ret;
}

static void __exit wl4455_exit(void)
{
	printk(KERN_ERR"wl4455_exit\n");
  	misc_deregister(&wl4455_misc);

	gpio_free(gpio_num_433);
}


module_init(wl4455_init);
module_exit(wl4455_exit);


MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("WL4455 Driver");

