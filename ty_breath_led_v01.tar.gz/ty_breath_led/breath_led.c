/*
 * Copyright (c) 2015 Olliver Schinagl <oliver@schinagl.nl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * This driver adds a high-resolution timer based PWM driver. Since this is a
 * bit-banged driver, accuracy will always depend on a lot of factors, such as
 * GPIO toggle speed and system load.
 */

#include <linux/mm.h>
#include <linux/fs.h>
#include <linux/clk.h>
#include <linux/pwm.h>
#include <linux/file.h>
#include <linux/list.h>
#include <linux/gpio.h>
#include <linux/time.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/module.h>
#include <linux/debugfs.h>
#include <linux/kthread.h>
#include <linux/mfd/core.h>
#include <linux/mempolicy.h>
#include <linux/interrupt.h>
#include <linux/mfd/jz_tcu.h>
#include <linux/miscdevice.h>
#include <linux/platform_device.h>
#include <linux/ktime.h>

#include <soc/irq.h>
#include <soc/base.h>
#include <soc/extal.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/cacheflush.h>
#include <soc/gpio.h>
#include <mach/platform.h>

#define BREATH_LED_STOP		0x0
#define BREATH_LED_START		0x1
#define WHITE_LED_CLOSE		0x2
#define WHITE_LED_OPEN		0x3
#define BREATH_LED_TIME_SET 0x4

#define BREATH_LED_DEVICE_NAME "breath_led"

struct breath_led_device {
	struct platform_device *pdev;
	struct device	 *dev;
	struct miscdevice misc_dev;
};


int gpio_num =40;
unsigned int on_time;
unsigned int off_time;
bool enable_flag;
bool pin_on;
struct hrtimer timer;
unsigned int set_breath_time = 0;
bool onetime_flag;
bool clear_n_num;

static int s_def_led_enable = 0;
module_param(s_def_led_enable, int, S_IRUGO);
MODULE_PARM_DESC(s_def_led_enable, "default led enable or disable by param set!");

static int s_def_heartbeat = 2;
module_param(s_def_heartbeat , int, S_IRUGO);
MODULE_PARM_DESC(s_def_heartbeat, "default led heartbeat cycle!");

#if 1
static int s_def_n_start = 0;
module_param(s_def_n_start, int, S_IRUGO);
MODULE_PARM_DESC(s_def_n_start, "default led start n by param set!");
#endif


#if 0
//是否开启次数统计，如果是则 呼吸周期为 s_def_heartbeat 则停止呼吸
static int s_def_onetime_enable = 0;
module_param(s_def_onetime_enable, int, S_IRUGO);
MODULE_PARM_DESC(s_def_onetime_enable, "default led heartbeat cycle times by param set!");
#endif
#ifndef CONFIG_TUYA_LED_GPIO
static unsigned int period[][2] = {
  {1,20000000},
  {100000,20000000},
  {200000,20000000},
  {300000,20000000},
  {400000,20000000},
  {500000,20000000},
  {600000,20000000},
  {700000,20000000},
  {800000,20000000},
  {900000,20000000},
  {1000000,10000000},
  {1100000,10000000},
  {1200000,10000000},
  {1300000,10000000},
  {1400000,10000000},
  {1500000,10000000},
  {1600000,10000000},
  {1700000,10000000},
  {1800000,10000000},
  {1900000,10000000},
  {2000000,10000000},
  {2100000,10000000},
  {2200000,10000000},
  {2300000,10000000},
  {2400000,10000000},
  {2500000,10000000},
  {2600000,10000000},
  {2700000,10000000},
  {2800000,10000000},
  {2900000,10000000},
  {3000000,10000000},
  {3100000,10000000},
  {3200000,10000000},
  {3300000,10000000},
  {3400000,10000000},
  {3500000,10000000},
  {3600000,10000000},
  {3700000,10000000},
  {3800000,10000000},
  {3900000,10000000},
  {4000000,10000000},
  {4100000,10000000},
  {4200000,10000000},
  {4300000,10000000},
  {4400000,10000000},
  {4500000,10000000},
  {4600000,10000000},
  {4700000,10000000},
  {4800000,10000000},
  {4900000,10000000},
  {5000000,10000000},
  {5100000,10000000},
  {5200000,10000000},
  {5300000,10000000},
  {5400000,10000000},
  {5500000,10000000},
  {5600000,10000000},
  {5700000,10000000},
  {5800000,10000000},
  {5900000,10000000},
  {6000000,10000000},
  {6100000,10000000},
  {6200000,10000000},
  {6300000,10000000},
  {6400000,10000000},
  {6500000,10000000},
  {6600000,10000000},
  {6700000,10000000},
  {6800000,10000000},
  {6900000,10000000},
  {7000000,10000000},
  {7100000,10000000},
  {7200000,10000000},
  {7300000,10000000},
  {7400000,10000000},
  {7500000,10000000},
  {7600000,10000000},
  {7700000,10000000},
  {7800000,10000000},
  {7900000,10000000},
  {8000000,10000000},
  {8100000,10000000},
  {8200000,10000000},
  {8300000,10000000},
  {8400000,10000000},
  {8500000,10000000},
  {8600000,10000000},
  {8700000,10000000},
  {8800000,10000000},
  {8900000,10000000},
  {9000000,10000000},
  {9100000,10000000},
  {9200000,10000000},
  {9300000,10000000},
  {9400000,10000000},
  {9500000,10000000},
  {9600000,10000000},
  {9700000,10000000},
  {9800000,10000000},
  {9900000,10000000},
  {9800000,10000000},
  {9700000,10000000},
  {9600000,10000000},
  {9500000,10000000},
  {9400000,10000000},
  {9300000,10000000},
  {9200000,10000000},
  {9100000,10000000},
  {9000000,10000000},
  {8900000,10000000},
  {8800000,10000000},
  {8700000,10000000},
  {8600000,10000000},
  {8500000,10000000},
  {8400000,10000000},
  {8300000,10000000},
  {8200000,10000000},
  {8100000,10000000},
  {8000000,10000000},
  {7900000,10000000},
  {7800000,10000000},
  {7700000,10000000},
  {7600000,10000000},
  {7500000,10000000},
  {7400000,10000000},
  {7300000,10000000},
  {7200000,10000000},
  {7100000,10000000},
  {7000000,10000000},
  {6900000,10000000},
  {6800000,10000000},
  {6700000,10000000},
  {6600000,10000000},
  {6500000,10000000},
  {6400000,10000000},
  {6300000,10000000},
  {6200000,10000000},
  {6100000,10000000},
  {6000000,10000000},
  {5900000,10000000},
  {5800000,10000000},
  {5700000,10000000},
  {5600000,10000000},
  {5500000,10000000},
  {5400000,10000000},
  {5300000,10000000},
  {5200000,10000000},
  {5100000,10000000},
  {5000000,10000000},
  {4900000,10000000},
  {4800000,10000000},
  {4700000,10000000},
  {4600000,10000000},
  {4500000,10000000},
  {4400000,10000000},
  {4300000,10000000},
  {4200000,10000000},
  {4100000,10000000},
  {4000000,10000000},
  {3900000,10000000},
  {3800000,10000000},
  {3700000,10000000},
  {3600000,10000000},
  {3500000,10000000},
  {3400000,10000000},
  {3300000,10000000},
  {3200000,10000000},
  {3100000,10000000},
  {3000000,10000000},
  {2900000,10000000},
  {2800000,10000000},
  {2700000,10000000},
  {2600000,10000000},
  {2500000,10000000},
  {2400000,10000000},
  {2300000,10000000},
  {2200000,10000000},
  {2100000,10000000},
  {2000000,10000000},
  {1900000,10000000},
  {1800000,10000000},
  {1700000,10000000},
  {1600000,10000000},
  {1500000,10000000},
  {1400000,10000000},
  {1300000,10000000},
  {1200000,10000000},
  {1100000,10000000},
  {1000000,10000000},
  {900000,20000000},
  {800000,20000000},
  {700000,20000000},
  {600000,20000000},
  {500000,20000000},
  {400000,20000000},
  {300000,20000000},
  {200000,20000000},
  {100000,20000000},
  {1,20000000},
};
#else
#define PWM_COUNT (50 * 2)
#define CIRCLE_TIME (1500 * 1000000) //Total time of led on and led off
#define PWM_COUNT_N1 10 			 //phase1 and phase4 pwm count
#define PWM_WIDTH_T1 (20 * 1000000)	 //phase1 and phase4 pwm pulse width, ns

static unsigned int period[PWM_COUNT][2];

/********************************************************************************
* Function: init_pwm_array
* Input: null
* Output: null
* Discription: This function is used to initial array period[][], which saves pwm 
* pulse width and duty time. phase 1 and phase 2 have longer led off time to 
* avoid breathing inconspicuously.
*
* phase1、phase4: pwm width = t1; pwm count = n1;	pwm duty ratio = ontime/t1;
* phase2、phase3: pwm width = t2; pwm count = n2;	pwm duty ratio = ontime/t2;
* ontime * (n1 + n2) = N;
********************************************************************************/
static void init_pwm_array(void)
{
	int i = 0;
	int mid = PWM_COUNT / 2, end = PWM_COUNT - 1;
	int n1 = PWM_COUNT_N1, t1 = PWM_WIDTH_T1;
	int n2 = PWM_COUNT / 2 - n1;
	int t2 = ((CIRCLE_TIME / 2) - (n1 * t1)) / n2;
	int ontime = t2 / (n1 + n2);

	//phase 1
	period[0][0] = 1;
	period[0][1] = t1;
	period[1][0] = ontime;
	period[1][1] = t1;

	for (i = 2; i < n1; i++) {
		period[i][1] = t1;
		period[i][0] = period[i - 1][0] + ontime;		
	}
	
	//phase 2
	for (i = n1; i < mid; i++) {
		period[i][1] = t2;
		period[i][0] = period[i - 1][0] + ontime;
		if (period[i][0] == ontime) {
			period[i][0] = period[i][0] - 1;
		}
	}
	
	//phase 3
	period[mid][1] = t2;
	period[mid][0] = period[mid - 1][0];
	for (i = mid + 1; i < mid + n2; i++) {
		period[i][1] = t2;
		period[i][0] = period[i - 1][0] - ontime;
	}
	
	//phase 4
	for (i = mid + n2; i < end; i++) {
		period[i][1] = t1;
		period[i][0] = period[i - 1][0] - ontime;
	}
	period[end][1] = t1;
	period[end][0] = 1;
}
#endif


//一开始从哪开始亮
//#define INI_START_INDEX    0  // 这个效果是 从暗慢慢 变亮
#define INI_START_INDEX     99

static void gpio_pwm_off(void)
{
	gpio_set_value(gpio_num,  0);
}

static void gpio_pwm_on(void)
{
	gpio_set_value(gpio_num, 1);
}

//fixmep
static int n = 0;//这个效果是 从最亮的地方开始变暗，承接 uboot 点亮的渐变
static enum hrtimer_restart gpio_pwm_timer(struct hrtimer *hrtimer)
{
	static int breath_times = 0;
#ifdef TIME_DEBUG
	struct timespec ts;
#endif
	if(!pin_on) {
		n = n % (sizeof(period)/sizeof(period[0]));
		on_time = period[n][0];
		off_time = (period[n][1] - period[n][0]);
	}
 
	if(clear_n_num == 1){
		clear_n_num = 0;
		n = 0;
		breath_times = 0;
	}	

  if((onetime_flag == 1) && (n == (sizeof(period)/sizeof(period[0])))){
#ifdef TIME_DEBUG
	ktime_get_ts(&ts);
	printk("mydebug info ############ : breath time %d, n = %d, ktime %ld s, %ld ms\n", breath_times, n, ts.tv_sec, ts.tv_nsec / (1000 * 1000));
#endif
	breath_times++;
    if(breath_times == set_breath_time){
      breath_times = 0;
      enable_flag = 0;
      onetime_flag = 0;
    }
  }

	if(!enable_flag) {
		gpio_pwm_off();
		pin_on = 0;
		return HRTIMER_NORESTART;
	}
 
	if (!pin_on) {
		hrtimer_forward_now(&timer, ns_to_ktime(on_time));

		if (on_time) {
		    if(on_time >= 10)
				gpio_pwm_on();
#ifdef TIME_DEBUG
			if(n == 0 || n == sizeof(period) / sizeof(period[0]) / 2 || n == sizeof(period) / sizeof(period[0])) {
				ktime_get_ts(&ts);
				printk("mydebug info ************** : n = %d, ktime %ld s, %ld ms\n", n, ts.tv_sec, ts.tv_nsec / (1000 * 1000));
			}
#endif
			pin_on = 1;
			n ++;
		}

	} else {
		hrtimer_forward_now(&timer, ns_to_ktime(off_time));

		if (off_time) {
		     if(off_time >= 10)
				gpio_pwm_off();
			pin_on = 0;
		}
	}

	return HRTIMER_RESTART;
}

static long breath_led_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	//struct miscdevice *dev = filp->private_data;

	switch (cmd) {
		case BREATH_LED_STOP:
			printk(KERN_ERR"breath_led_disable\n");
	    gpio_pwm_off();
	    enable_flag = 0;
	    onetime_flag = 0;
		clear_n_num = 1;
			break;
		
		case BREATH_LED_START:
			{
				printk(KERN_ERR"breath_led_enable\n");

        if(enable_flag)
        	return -EBUSY;

        enable_flag = 1;

        if (on_time && off_time) {
          
        	hrtimer_start(&timer, ktime_set(0, 10), HRTIMER_MODE_REL);
        } else {
        	if (on_time)
        		gpio_pwm_on();
        	else
        		gpio_pwm_off();
        }

        
			}
			break;

    case WHITE_LED_CLOSE:
			printk(KERN_ERR"white_led_close\n");
	    gpio_pwm_off();
			break;

    case WHITE_LED_OPEN:
			printk(KERN_ERR"white_led_open\n");
	    gpio_pwm_on();
			break;
    
    case BREATH_LED_TIME_SET:
			{
			  printk(KERN_ERR"set %d times breath_led\n", arg);

        if(enable_flag)
        	return -EBUSY;

        enable_flag = 1;
        onetime_flag = 1;
        set_breath_time = (unsigned int)arg;
		
        if (on_time && off_time) {
          
        	hrtimer_start(&timer, ktime_set(0, 10), HRTIMER_MODE_REL);
        } else {
        	if (on_time)
        		gpio_pwm_on();
        	else
        		gpio_pwm_off();
        }   
			}
			break;
			
		default:
			return -EINVAL;
	}

	return 0;
}
static struct file_operations breath_led_fops = {
	.unlocked_ioctl = breath_led_ioctl,
};

struct miscdevice breath_led_misc = {
    .minor  = MISC_DYNAMIC_MINOR,
    .name   = BREATH_LED_DEVICE_NAME,
    .fops   = &breath_led_fops,
};

static int __init pwm_gpio_init(void)
{
  int ret = 0;
  

  printk(KERN_ERR"pwm_gpio_init\n");

#ifdef CONFIG_TUYA_LED_GPIO
	init_pwm_array();
#endif

	if(gpio_request(gpio_num, "breath_led")) {
	      printk(KERN_DEBUG"request gpio %d error!\n",gpio_num);
	      return -1;
      	}
		
    gpio_direction_output(40, 1);
	gpio_set_value(40,0);//默认是暗的， 此时uboot需要关闭LED

    printk(KERN_ERR"HRTIMER init default enable=%d\n", s_def_led_enable);
	hrtimer_init(&timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	timer.function = &gpio_pwm_timer;

	if (!hrtimer_is_hres_active(&timer))
		printk(KERN_ERR"HR timer unavailable, restricting to low resolution\n");

	pin_on = 0;
	on_time = 0x50000; 
	off_time = 0x50000;
  	enable_flag = 0;

	if (s_def_led_enable > 0) {
		enable_flag = 1;
		set_breath_time = s_def_heartbeat;
		if (s_def_heartbeat > 0){
			onetime_flag    = 1;
		}
		#if 1
		if (s_def_n_start > (sizeof(period)/sizeof(period[0]))) {
			s_def_n_start = INI_START_INDEX;
		}
		if (s_def_n_start > 0) {
			n = s_def_n_start;
		}
		#else
		if (0 == n) {
			n = 25;
			//n = (sizeof(period)/sizeof(period[0]))/2; //  99  这个效果是 从最亮的地方开始变暗，承接 uboot 点亮的渐变 INI_START_INDEX;
		}
		#endif
		printk("HR timer enable_flag=%d s_def_heartbeat=%d start=%d onetime_flag=%d\n", enable_flag, s_def_heartbeat, n, onetime_flag);
	}
	
	hrtimer_start(&timer, ktime_set(0, 10), HRTIMER_MODE_REL);
	

	ret = misc_register(&breath_led_misc);
	if (ret < 0) {
		ret = -ENOENT;
		printk(KERN_ERR"misc_register failed\n");

	}

	printk(KERN_ERR"add breath led misc_register succeed\n");

	return ret;
}

static void __exit pwm_gpio_exit(void)
{
	printk(KERN_ERR"pwm_gpio_exit\n");
	misc_deregister(&breath_led_misc);

	hrtimer_cancel(&timer);
	gpio_free(gpio_num);
}


module_init(pwm_gpio_init);
module_exit(pwm_gpio_exit);


MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("PWM GPIO Driver");

